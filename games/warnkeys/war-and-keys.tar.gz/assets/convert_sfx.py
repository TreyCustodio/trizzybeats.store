from pathlib import Path
import shutil
import subprocess
import sys

"""
.wav to .ogg conversion file
written entirely by Perplexity.ai
"""
SFX_FOLDER = Path("sfx")
QUALITY = "5"  # Vorbis quality: -1 (smallest) through 10 (highest)

def main():
    if not SFX_FOLDER.is_dir():
        print(f'Error: Could not find folder "{SFX_FOLDER}".')
        sys.exit(1)

    if shutil.which("ffmpeg") is None:
        print("Error: FFmpeg was not found in your PATH.")
        print("Install FFmpeg, restart your terminal, then run this script again.")
        sys.exit(1)

    wav_files = list(SFX_FOLDER.rglob("*.wav")) + list(SFX_FOLDER.rglob("*.WAV"))

    if not wav_files:
        print(f'No WAV files found in "{SFX_FOLDER}".')
        return

    converted = 0
    skipped = 0
    failed = 0

    for wav_file in wav_files:
        ogg_file = wav_file.with_suffix(".ogg")

        if ogg_file.exists():
            print(f"Skipping (already exists): {ogg_file}")
            skipped += 1
            continue

        command = [
            "ffmpeg",
            "-y",
            "-i", str(wav_file),
            "-c:a", "libvorbis",
            "-q:a", QUALITY,
            str(ogg_file),
        ]

        print(f"Converting: {wav_file} -> {ogg_file}")

        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )

        if result.returncode == 0:
            converted += 1
        else:
            failed += 1
            print(f"Failed: {wav_file}")
            print(result.stderr)

    print(f"\nDone: {converted} converted, {skipped} skipped, {failed} failed.")

if __name__ == "__main__":
    main()